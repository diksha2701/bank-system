WELCOME TO MY PROJECT ON BANK WEBSITE.

			PROJECT MADE BY SAPNA KUMARI.

	Spark Foundation Web Development Internship Project : Basic Banking System Website.
	A web application used to transfer virtual money between multiple users and 
		also record the banking transactions/activities.

        The website has following specification -

	A dummy data for upto 10 customers.
	Customers table with basic fields such as name , email, current balance
	Transaction status